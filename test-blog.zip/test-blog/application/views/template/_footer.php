    <footer class="footer">
    	<div class="container">
    		<p class="pull-left">&copy; My Company 2024</p>

    		<p class="pull-right">Powered by <a href="http://www.yiiframework.com/" rel="external">Yii Framework</a></p>
    	</div>
    </footer>

    <script src="<?php echo base_url(); ?>/assets/js/jquery.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/bootstrap.js"></script>
    </body>

    </html>