<!DOCTYPE html>
<html lang="id">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-param" content="_csrf">
	<meta name="csrf-token" content="dTHWTr7HcoKoZk5dK-Hfc1fW8ThWdN5ei8SU-HxJC4sUYKUl3Lc08fIBAj9-p5VCb4zBWyUjpzG9o6C0EBky8Q==">
	<title>My Yii Application</title>
	<link href="<?php echo base_url(); ?>/assets/css/bootstrap.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>/assets/css/site.css" rel="stylesheet">
</head>


<body>