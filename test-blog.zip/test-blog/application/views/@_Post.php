    <div class="wrap">
        <nav id="w1" class="navbar-inverse navbar-fixed-top navbar">
            <div class="container">
                <div class="navbar-header"><button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#w1-collapse"><span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span></button><a class="navbar-brand" href="<?php echo base_url(); ?>">My Application</a></div>
                <div id="w1-collapse" class="collapse navbar-collapse">
                    <ul id="w2" class="navbar-nav navbar-right nav">
                        <li><a href="<?php echo base_url(); ?>">Home</a></li>
                        <li class="active"><a href="<?php echo base_url(); ?>blog/web/post/index">Post</a></li>
                        <li><a href="<?php echo base_url(); ?>blog/web/account/index">Akun</a></li>
                        <li>
                            <form action="<?php echo base_url(); ?>blog/web/site/logout" method="post">
                                <input type="hidden" name="_csrf" value="1_P9BGF9XBOcoJJvGQhr-M4SI6GUq88lc5LjGPfbyW22oo5vAw0aYMbH3g1MTiHJ9kgTwuf8tkpF9ddUm4vwFw=="><button type="submit" class="btn btn-link logout">Logout (admin)</button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container">
            <ul class="breadcrumb">
                <li><a href="<?php echo base_url(); ?>blog/web/">Beranda</a></li>
                <li class="active">Posts</li>
            </ul>
            <div class="post-index">

                <h1>Posts</h1>

                <p>
                    <a class="btn btn-success" href="<?php echo base_url(); ?>blog/web/post/create">Create Post</a>
                </p>

                <div id="w0" class="grid-view">
                    <div class="summary">Menampilkan <b>1-2</b> dari <b>2</b> item.</div>
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th><a href="<?php echo base_url(); ?>blog/web/post/index?sort=title" data-sort="title">Title</a></th>
                                <th><a href="<?php echo base_url(); ?>blog/web/post/index?sort=content" data-sort="content">Content</a></th>
                                <th><a href="<?php echo base_url(); ?>blog/web/post/index?sort=date" data-sort="date">Date</a></th>
                                <th><a href="<?php echo base_url(); ?>blog/web/post/index?sort=username" data-sort="username">Username</a></th>
                                <th class="action-column">&nbsp;</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr data-key="1">
                                <td>1</td>
                                <td>Soal Test</td>
                                <td>
                                    <p><strong>Buatlah Blog seperti ini dalam WAKTU 2 JAM dengan ketentuan :</strong></p>

                                    <ol>
                                        <li>Menu :
                                            <ul>
                                                <li>Beranda</li>
                                                <li>Post : CRUD Post</li>
                                                <li>Akun : CRUD Akun</li>
                                                <li>Login / Logout</li>
                                            </ul>
                                        </li>
                                        <li>Terdapat 2 Role :
                                            <ul>
                                                <li>Admin dapat membuat Akun baru dan Post baru (CRUD)</li>
                                                <li>Author hanya dapat membuat post baru (CRUD)</li>
                                            </ul>
                                        </li>
                                        <li>User dummy untuk login melihat CRUD :
                                            <ul>
                                                <li>admin admin</li>
                                                <li>author author</li>
                                            </ul>
                                        </li>
                                        <li>Upload source code hasilnya pada repositori publik (misal github, bitbucket dsb)</li>
                                    </ol>
                                </td>
                                <td>2022-02-01 11:14:55</td>
                                <td>admin</td>
                                <td><a href="<?php echo base_url(); ?>blog/web/post/view?id=1" title="Lihat" aria-label="Lihat" data-pjax="0"><span class="glyphicon glyphicon-eye-open"></span></a> <a href="<?php echo base_url(); ?>blog/web/post/update?id=1" title="Ubah" aria-label="Ubah" data-pjax="0"><span class="glyphicon glyphicon-pencil"></span></a> <a href="<?php echo base_url(); ?>blog/web/post/delete?id=1" title="Hapus" aria-label="Hapus" data-pjax="0" data-confirm="Apakah Anda yakin ingin menghapus item ini?" data-method="post"><span class="glyphicon glyphicon-trash"></span></a></td>
                            </tr>
                            <tr data-key="2">
                                <td>2</td>
                                <td>Database Dump</td>
                                <td>
                                    <p><code>CREATE TABLE IF NOT EXISTS `account` (<br />
                                            `username` VARCHAR(45) NOT NULL,<br />
                                            `password` VARCHAR(250) NOT NULL,<br />
                                            `name` VARCHAR(45) NOT NULL,<br />
                                            `role` VARCHAR(45) NOT NULL,<br />
                                            PRIMARY KEY (`username`))<br />
                                            ENGINE = InnoDB;</code></p>

                                    <p><code>CREATE TABLE IF NOT EXISTS `post` (<br />
                                            `idpost` INT NOT NULL AUTO_INCREMENT,<br />
                                            `title` TEXT NOT NULL,<br />
                                            `content` TEXT NOT NULL,<br />
                                            `date` DATETIME NOT NULL,<br />
                                            `username` VARCHAR(45) NOT NULL,<br />
                                            PRIMARY KEY (`idpost`),<br />
                                            INDEX `fk_post_account_idx` (`username` ASC),<br />
                                            CONSTRAINT `fk_post_account`<br />
                                            FOREIGN KEY (`username`)<br />
                                            REFERENCES `account` (`username`)<br />
                                            ON DELETE NO ACTION<br />
                                            ON UPDATE NO ACTION)<br />
                                            ENGINE = InnoDB;</code></p>
                                </td>
                                <td>2018-02-02 00:31:00</td>
                                <td>author</td>
                                <td><a href="<?php echo base_url(); ?>blog/web/post/view?id=2" title="Lihat" aria-label="Lihat" data-pjax="0"><span class="glyphicon glyphicon-eye-open"></span></a> <a href="<?php echo base_url(); ?>blog/web/post/update?id=2" title="Ubah" aria-label="Ubah" data-pjax="0"><span class="glyphicon glyphicon-pencil"></span></a> <a href="<?php echo base_url(); ?>blog/web/post/delete?id=2" title="Hapus" aria-label="Hapus" data-pjax="0" data-confirm="Apakah Anda yakin ingin menghapus item ini?" data-method="post"><span class="glyphicon glyphicon-trash"></span></a></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>