    <div class="wrap">
        <nav id="w1" class="navbar-inverse navbar-fixed-top navbar">
            <div class="container">
                <div class="navbar-header"><button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#w1-collapse"><span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span></button><a class="navbar-brand" href="<?php echo base_url(); ?>">My Application</a></div>
                <div id="w1-collapse" class="collapse navbar-collapse">
                    <ul id="w2" class="navbar-nav navbar-right nav">
                        <li><a href="<?php echo base_url(); ?>">Home</a></li>
                        <li><a href="<?php echo base_url(); ?>blog/web/post/index">Post</a></li>
                        <li><a href="<?php echo base_url(); ?>blog/web/account/index">Akun</a></li>
                        <li>
                            <form action="<?php echo base_url(); ?>blog/web/site/logout" method="post">
                                <input type="hidden" name="_csrf" value="4yWHfhfm34RGxvAuTh42ThzvBmZVydpunhBHUQl31OKCdPQVdZaZ9xyhvEwbWHx_JLU2BSaeowGod3MdZSftmA=="><button type="submit" class="btn btn-link logout">Logout (admin)</button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container">
            <ul class="breadcrumb">
                <li><a href="<?php echo base_url(); ?>blog/web/">Beranda</a></li>
                <li><a href="<?php echo base_url(); ?>blog/web/account/index">Accounts</a></li>
                <li class="active">Create Account</li>
            </ul>
            <div class="account-create">

                <h1>Create Account</h1>


                <div class="account-form">
                    <form method="post" action="<?php echo base_url('blog/web/account/create_acount'); ?>">
                        <div class="form-group field-account-username required">
                            <label class="control-label" for="account-username">Username</label>
                            <input type="text" name="account-username" class="form-control" maxlength="45" aria-required="true">

                            <div class="help-block"></div>
                        </div>
                        <div class="form-group field-account-password required">
                            <label class="control-label" for="account-password">Password</label>
                            <input type="password" name="account-password" class="form-control" maxlength="250" aria-required="true">

                            <div class="help-block"></div>
                        </div>
                        <div class="form-group field-account-name required">
                            <label class="control-label" for="account-name">Name</label>
                            <input type="text" name="account-name" class="form-control" maxlength="45" aria-required="true">

                            <div class="help-block"></div>
                        </div>
                        <div class="form-group field-account-role required">
                            <label class="control-label" for="account-role">Role</label>
                            <select name="account-role" class="form-control" aria-required="true">
                                <option value="admin">Admin</option>
                                <option value="author">Author</option>
                            </select>

                            <div class="help-block"></div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-success">Save</button>
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>