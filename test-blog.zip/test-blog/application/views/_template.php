<?php $this->load->view('template/_head'); ?>
<?= $contents; ?>
<?php $this->load->view('template/_footer'); ?>