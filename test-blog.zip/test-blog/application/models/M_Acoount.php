<?php class M_Acoount extends CI_Model
{
    public function InsertAcount($data)
    {
        $query = $this->db->insert('account', $data);
        return $query;
    }
}
