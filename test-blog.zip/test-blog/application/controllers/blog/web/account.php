<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Account extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('M_Acoount', 'model');
    }
    function index()
    {
        $this->template->load('_template', '@_Akun');
    }
    function create()
    {
        $this->template->load('_template', '@_CreateAkun');
    }
    function create_acount()
    {
        $datainsert = [
            "username" => $this->input->post('account_username'),
            "password" => $this->input->post('account_password'),
            "name" => $this->input->post('account_name'),
            "role" => $this->input->post('account_role'),
        ];
        print_r($datainsert);
        die();

        $this->model->InsertAcount($datainsert);
        $this->session->set_flashdata('message', '<div class="alert alert-success">Record has been saved successfully.</div>');
        redirect(base_url());
    }
}
